<div>
    <form method="GET">
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
        @endif
        <input type="text" placeholder="Nombre" name="nombre">
        <input type="submit" value="Iniciar sesion">
    </form>
</div>
<br><br><br>
<a href="{{ route('entrenadores.index') }}">Entrenadores</a>

<style>
    .volver {
        position: absolute;
        top: 1pc;
        left: 3pc;
    }

    .volver>form>input {
        width: fit-content;
    }

    form {
        display: flex;
        flex-direction: column;
        row-gap: 1em;
        width: 30em;
        position: absolute;
        top: 20%;
        left: 35%
    }
</style>
