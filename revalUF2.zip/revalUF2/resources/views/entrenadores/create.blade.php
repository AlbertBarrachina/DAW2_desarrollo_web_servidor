<!-- resources/views/entrenadores/create.blade.php -->
@extends('layouts.app')

@section('content')
    <h1>Alta entrenador</h1>


    <form action="{{ route('entrenadores.store') }}" method="post">
        @csrf

        <label for="idEntrenador">idEntrenador:</label>
        <input type="number" name="idEntrenador" required>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="fechaN">Fecha nacimiento:</label>
        <input type="date" name="fechaN" required>

        <label for="ciudad">Ciudad:</label>
        <input type="text" name="ciudad" required>

        <button type="submit">Guardar</button>
    </form>
@endsection
