<!-- resources/views/pokemons/index.blade.php -->
@extends('layouts.app')

@section('content')
<h1>Listado entrenadores</h1>

<table>
    <thead>
        <tr>
            <th>idEntrenador</th>
            <th>Nombre</th>
            <th>Fecha nacimiento</th>
            <th>Ciudad</th>
        </tr>
    </thead>
    <tbody>
        @foreach($entrenadores as $entrenador)
        <tr>
            <td>{{ $entrenador->idEntrenador }}</td>
            <td>{{ $entrenador->nombre }}</td>
            <td>{{ $entrenador->fechaN }}</td>
            <td>{{ $entrenador->ciudad }}</td>
            <td><a href="{{ route('entrenadores.edit', $entrenador->id) }}">Editar</a></td>
            @if($userRol == 'Admin')
            <td>
                <form action="{{ route('entrenadores.destroy', $entrenador->id) }}" method="post">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Eliminar</button>
                </form>
            </td>
            @endif
        </tr>
        @endforeach
    </tbody>
</table>

@if($userRol == 'Admin')
<a href="{{ route('entrenadores.create') }}">Añadir</a>
@endif
<br><br><br>
<p>middleware comentado porque entra en bucle</p>
@endsection