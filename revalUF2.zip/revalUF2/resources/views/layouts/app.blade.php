<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Laravel App</title>
</head>
<body>
    @yield('content')
    <br><br><br><br><br>
    <a href="{{ route('entrenadores.index') }}">Entrenadores</a>
    <br>
    <a href="{{ route('entrenadores.Login') }}">Login</a>
</body>
</html>
