<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Pokemon;

class Entrenador extends Model
{
    use HasFactory;

    protected $table = 'entrenador';
    protected $fillable = [
        'nombre',
        'fechaN',
        'ciudad',
        'idEntrenador'
    ];

    //crear relación 1 a muchos
    public function pokemons()
    {
        return $this->hasMany(Pokemon::class, 'idEntrenador');
    }
}
