<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Entrenador;

class EntrenadorController extends Controller
{
    /* PÁGINA INICIAL */
    public function index()
    {
        $entrenadores = Entrenador::all();
        return view('entrenadores.index', compact('entrenadores'));
    }
    /*show porque al parecer el index no es lo suficientemente bueno*/
    public function show()
    {
        $entrenadores = Entrenador::all();
        return view('entrenadores.index', compact('entrenadores'));
    }

    /* CREACIÓN */
    public function create()
    {
        return view('entrenadores.create');
    }

    /* GUARDAR */
    public function store(Request $request)
    {
        //añade aquí la funcionalidad
        $request->validate([
            'nombre' => 'required',
            'fechaN' => 'required|date',
            'ciudad' => 'required',
            'idEntrenador' => 'required',
        ]);

        Entrenador::create($request->all());

        return redirect()->route('entrenador.index');
    }

    /* EDITAR */
    public function edit(Entrenador $entrenador)
    {
        return view('entrenadores.edit', compact('entrenador'));
    }

    /* ACTUALIZAR */
    public function update(Request $request, Entrenador $entrenador)
    {
        //añade aquí la funcionalidad
        $request->validate([
            'nombre' => 'required',
            'fechaN' => 'required|date',
            'ciudad' => 'required',
        ]);

        $entrenador->update($request->all());
        return redirect()->route('entrenadores.index');
    }

    /*ELIMINAR*/
    public function destroy(Entrenador $id)
    {
        //añade aquí la funcionalidad
        $entrenador = Entrenador::findOrFail($id);

        $entrenador->delete();
        return redirect()->route('entrenadores.index');
    }

    /* login, redirige al login*/ 
    public function Login()
    {
        return view('Login');
    }

}
