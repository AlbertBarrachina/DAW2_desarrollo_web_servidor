<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pokemon;

class PokemonController extends Controller
{
    //cargar página principal
    public function index()
    {
        $pokemons = Pokemon::all();
        return view('pokemons.index', compact('pokemons'));
    }

    public function show(Pokemon $pokemon)
    {
        $pokemons = Pokemon::all();
        return redirect()->route('pokemons.index', compact('pokemon'));
    }

    //página de creación
    public function create()
    {
        return view('pokemons.create');
    }

    //guarda información en BD
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamanio' => 'nullable|in:grande,mediano,pequeño',
            'mote' => 'nullable|string',
            ], [ 'tamanio.in' => 'El tamaño seleccionado no es válido.']);

        Pokemon::create($request->all());

        return redirect()->route('pokemons.index');
    }

    public function edit(Pokemon $pokemon)
    {
        return view('pokemons.edit', compact('pokemon'));
    }

    public function update(Request $request, Pokemon $pokemon)
    {
        $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamanio' => 'required|in:grande,mediano,pequeño',
            'mote' => 'nullable|string',
        ]);

        $pokemon->update($request->all());

        return redirect()->route('pokemons.index');
    }

    public function destroy(Pokemon $pokemon)
    {
        $pokemon->delete();

        return redirect()->route('pokemons.index');
    }
}
