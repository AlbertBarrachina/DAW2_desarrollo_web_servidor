<?php

namespace App\Http\Middleware;


use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Entrenador;

class SesionEntrenador
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        /*$nombre = $request->input('nombre');

        $entrenador = Entrenador::where('nombre', $nombre)->first();
        if($entrenador){
            if ($entrenador->nombre == "Sandra") {
                $userRol = "Admin";
            } else {
                $userRol = 'Usuario';
            }
            view()->share('userRol', $userRol);
            if ($userRol == 'Sandra') {
                return redirect('/pokemons/index');
            } elseif ($userRol == 'Usuario') {
                return redirect('/entrenadores/index');
            }
        }else{
             return redirect('/Login')->with('error', 'Entrenador no existe');
        }
            */
         $userRol = 'Admin';  
            view()->share('userRol', $userRol);
        // Share the user role with all views

        return $next($request);
    }
}
