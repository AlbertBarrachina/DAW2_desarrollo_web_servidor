<!-- resources/views/pokemons/edit.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Editar Pokémon</h1>

    <form>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" step="0.01" value="<?php echo e($entrenador->nombre); ?>" required>

        <label for="ciudad">Ciudad:</label>
        <input type="text" name="ciudad" step="0.01" value="<?php echo e($entrenador->ciudad); ?>" required>

        <label for="fechaN">Fecha nacimiento:</label>
        <input type="date" name="fechaN" step="0.01" value="<?php echo e($entrenador->fechaN); ?>" required>

        <button type="submit">Actualizar información</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/entrenadores/edit.blade.php ENDPATH**/ ?>