<!-- resources/views/entrenadores/create.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Alta entrenador</h1>


    <form action="<?php echo e(route('entrenadores.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label for="idEntrenador">idEntrenador:</label>
        <input type="number" name="idEntrenador" required>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="fechaN">Fecha nacimiento:</label>
        <input type="date" name="fechaN" required>

        <label for="ciudad">Ciudad:</label>
        <input type="text" name="ciudad" required>

        <button type="submit">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/entrenadores/create.blade.php ENDPATH**/ ?>