<!-- resources/views/pokemons/create.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Agregar Pokémon</h1>

    <form action="<?php echo e(route('pokemons.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="agua">Agua</option>
            <option value="fuego">Fuego</option>
            <option value="planta">Planta</option>
            <!-- Agrega más tipos según sea necesario -->
        </select>

        <label for="tamaño">Tamaño:</label>
        <select name="tamaño">
            <option value="">---</option>
            <option value="grande">Grande</option>
            <option value="mediano">Mediano</option>
            <option value="pequeño">Pequeño</option>
        </select>

        <label for="mote">Peso:</label>
        <input type="text" name="mote" step="0.01">

        <button type="submit">Guardar Pokémon</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/pokemons/create.blade.php ENDPATH**/ ?>