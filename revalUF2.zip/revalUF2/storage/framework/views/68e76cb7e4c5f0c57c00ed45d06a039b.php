<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Laravel App</title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <br><br><br><br><br>
    <a href="<?php echo e(route('entrenadores.index')); ?>">Entrenadores</a>
    <br>
    <a href="<?php echo e(route('entrenadores.Login')); ?>">Login</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/layouts/app.blade.php ENDPATH**/ ?>