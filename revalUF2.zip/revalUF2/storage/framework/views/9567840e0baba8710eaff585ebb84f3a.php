<!-- resources/views/pokemons/index.blade.php -->


<?php $__env->startSection('content'); ?>
<h1>Listado entrenadores</h1>

<table>
    <thead>
        <tr>
            <th>idEntrenador</th>
            <th>Nombre</th>
            <th>Fecha nacimiento</th>
            <th>Ciudad</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $entrenadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrenador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($entrenador->idEntrenador); ?></td>
            <td><?php echo e($entrenador->nombre); ?></td>
            <td><?php echo e($entrenador->fechaN); ?></td>
            <td><?php echo e($entrenador->ciudad); ?></td>
            <td><a href="<?php echo e(route('entrenadores.edit', $entrenador->id)); ?>">Editar</a></td>
            <?php if($userRol == 'Admin'): ?>
            <td>
                <form action="<?php echo e(route('entrenadores.destroy', $entrenador->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Eliminar</button>
                </form>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if($userRol == 'Admin'): ?>
<a href="<?php echo e(route('entrenadores.create')); ?>">Añadir</a>
<?php endif; ?>
<br><br><br>
<form action="<?php echo e(route('entrenadores.Admin')); ?>">
    <button>Admin</button>
</form>
<form action="<?php echo e(route('entrenadores.Usuario')); ?>">
    <button>Usaurio</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/entrenadores/index.blade.php ENDPATH**/ ?>