<!-- resources/views/pokemons/edit.blade.php -->


<?php $__env->startSection('content'); ?>
    <h1>Editar Pokémon</h1>

    <form action="<?php echo e(route('pokemons.update', $pokemon->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="<?php echo e($pokemon->nombre); ?>" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="agua" <?php echo e($pokemon->tipo === 'agua' ? 'selected' : ''); ?>>Agua</option>
            <option value="fuego" <?php echo e($pokemon->tipo === 'fuego' ? 'selected' : ''); ?>>Fuego</option>
            <option value="planta" <?php echo e($pokemon->tipo === 'planta' ? 'selected' : ''); ?>>Planta</option>
            <!-- Agrega más tipos según sea necesario -->
        </select>

        <label for="tamaño">Tamaño:</label>
        <select name="tamaño" required>
            <option value="grande" <?php echo e($pokemon->tamaño === 'grande' ? 'selected' : ''); ?>>Grande</option>
            <option value="mediano" <?php echo e($pokemon->tamaño === 'mediano' ? 'selected' : ''); ?>>Mediano</option>
            <option value="pequeño" <?php echo e($pokemon->tamaño === 'pequeño' ? 'selected' : ''); ?>>Pequeño</option>
        </select>

        <label for="mote">Peso:</label>
        <input type="text" name="mote" step="0.01" value="<?php echo e($pokemon->mote); ?>" required>

        <button type="submit">Actualizar Pokémon</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revalUF2\resources\views/pokemons/edit.blade.php ENDPATH**/ ?>