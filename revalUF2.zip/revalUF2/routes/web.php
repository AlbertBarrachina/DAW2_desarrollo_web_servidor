<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;
use App\Http\Controllers\EntrenadorController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/', function () {
    return view('layouts.app');
});
//funcionalidad de pokemons
Route::resource('pokemons', PokemonController::class);
//entrenadores
Route::resource('entrenadores', EntrenadorController::class);
Route::get('/entrenadores', [EntrenadorController::class, 'index'])
    ->name('entrenadores.index');
Route::get('/Login', [EntrenadorController::class, 'Login'])
    ->name('entrenadores.Login');
