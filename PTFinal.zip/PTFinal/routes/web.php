<?php

use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\tiendaController;
use App\Http\Controllers\UsuarioController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('tienda.index');
});
Route::resource('tienda', TiendaController::class);
Route::resource('producto', ProductoController::class);
Route::resource('categoria', CategoriaController::class);
Route::resource('usuario', UsuarioController::class);
Route::resource('carrito', UsuarioController::class);

Route::middleware(['AdminCheck'])->group(function () {
    Route::get('ShowAdmin', [TiendaController::class, 'showadmin'])->name('tienda.ShowAdmin');
    Route::patch('UpdatePerfil', [TiendaController::class, 'UpdatePerfil'])->name('tienda.UpdatePerfil');
    Route::get('producto/create', [ProductoController::class, 'create'])->name('producto.create');
    Route::get('categoria/create', [CategoriaController::class, 'create'])->name('categoria.create');
    Route::get('usuario/create', [UsuarioController::class, 'create'])->name('usuario.create');
});

/* shows*/
Route::get('ShowLogin', [TiendaController::class, 'ShowLogin'])->name('tienda.ShowLogin');
Route::get('ShowRegister', [TiendaController::class, 'ShowRegister'])->name('tienda.ShowRegister');
Route::get('Perfil', [TiendaController::class, 'Perfil'])->name('tienda.Perfil');

/*otros*/
Route::get('Login', [TiendaController::class, 'Login'])->name('tienda.Login');
Route::get('Logout', [TiendaController::class, 'Logout'])->name('tienda.Logout');

