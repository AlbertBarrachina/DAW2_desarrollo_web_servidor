<div>
    <p>
        Tablero categorias
    </p>
    <form action="<?php echo e(route ('producto.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="descripcion" placeholder="Descripción">
        <input type="number" name="unidades" value="1">
        <input type="number" name="precio_unitario" value="1">
        <select name="categoria">
            <option value="">--</option>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($categoria->nombre); ?>"><?php echo e($categoria->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">--</option>
            <?php endif; ?>
        </select>
        <button type="submit">Crear producto</button>
    </form>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/CrearProducto.blade.php ENDPATH**/ ?>