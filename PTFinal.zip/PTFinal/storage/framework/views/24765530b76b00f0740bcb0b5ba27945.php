<?php if(session('UserRol') != 'guest'): ?>
<form action="<?php echo e(route('tienda.Logout')); ?>" method="GET">
    <input type="submit" value="Cerrar sesion">
</form>
<?php elseif(session('UserRol') == 'guest'): ?>
<p>Inicia sesion o registrate!</p>
<div>
    <form action="<?php echo e(route('tienda.ShowLogin')); ?>" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="<?php echo e(route('tienda.ShowRegister')); ?>" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
<?php endif; ?>
<div>
    <p>
        Perfil de <?php echo e($usuario->nick); ?>

    </p>
    <table border=1>
        <thead>
            <tr>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <!--Formulario para actualizar los usuarios-->
                <form action="<?php echo e(route('tienda.UpdatePerfil')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input hidden type="number" name="id" value="<?php echo e($usuario->id); ?>">
                    <td><input type="text" value="<?php echo e($usuario->nick); ?>" name="nick"></td>
                    <td><input type="text" value="<?php echo e($usuario->email); ?>" name="email"></td>
                    <td><?php echo e($usuario->nombre); ?></td>
                    <td><?php echo e($usuario->apellidos); ?></td>
                    <td><?php echo e($usuario->dni); ?></td>
                    <td><?php echo e($usuario->fecha_nacimiento); ?></td>
                    <td><?php echo e($usuario->contraseña); ?></td>
                    <td><?php echo e($usuario->rol); ?></td>
                    <td>
                        <input type="submit" value="Actualizar usuario">
                    </td>
                </form>
            </tr>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/perfil.blade.php ENDPATH**/ ?>