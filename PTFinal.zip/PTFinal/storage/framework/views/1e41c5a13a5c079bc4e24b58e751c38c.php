<div>
    <form action="<?php echo e(route('tienda.show')); ?>" method="GET">
        <input type="submit" value="Iniciar sesioon">
    </form>
    <form action="<?php echo e(route('tienda.showRegister')); ?>" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div><?php /**PATH C:\xampp\htdocs\practicaFinal\resources\views/tienda/index.blade.php ENDPATH**/ ?>