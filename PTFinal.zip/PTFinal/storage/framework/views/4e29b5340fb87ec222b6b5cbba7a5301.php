<div>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->unidades); ?></td>
                <td><?php echo e($producto->precio_unitario); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td>
                    <form action="<?php echo e(route('tienda.editProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route ('tienda.destroyProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($userRol); ?>

<?php if($userRol == 'Admin'): ?>
    <form action="<?php echo e(route('tienda.showAdmin')); ?>">
        <button action="submit">Zona admin</button>
    </form>
<?php elseif($userRol == 'Usuario'): ?>
    <p>Howdy Usuario! Doxeado! :3 <?php echo e(session('UserRol')); ?></p>
<?php else: ?>
    <p>Inicia sesion o registrate!</p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/productos.blade.php ENDPATH**/ ?>