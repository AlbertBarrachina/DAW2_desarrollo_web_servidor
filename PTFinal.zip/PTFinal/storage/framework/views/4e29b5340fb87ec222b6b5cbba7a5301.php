<div>
    <p>
        Tablero productos
    </p>
    <form action="<?php echo e(route('tienda.Perfil')); ?>" method="GET">
        <input type="submit" value="Perfil">
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!--Formulario para actualizar los productos-->
                <form action="<?php echo e(route('carrito.store', $producto->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POT'); ?>
                    <td><?php echo e($producto->id); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td><?php echo e($producto->unidades); ?></td>
                    <td><?php echo e($producto->precio_unitario); ?></td>
                    <td><?php echo e($producto->categoria); ?></td>
                    <td><input type="number" name="cantidad" value="0"></td>
                    <td>
                        <input type="submit" value="Añadir al carrito">
                    </td>
                </form>
            </tr>
            <!--mensaje de no productos-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/productos.blade.php ENDPATH**/ ?>