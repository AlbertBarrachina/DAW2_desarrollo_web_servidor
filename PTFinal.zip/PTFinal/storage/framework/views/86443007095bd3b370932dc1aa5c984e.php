<?php if(session('UserRol') != 'guest'): ?>
<form action="<?php echo e(route('tienda.Logout')); ?>" method="GET">
    <input type="submit" value="Cerrar sesion">
</form>
<?php elseif(session('UserRol') == 'guest'): ?>
<p>Inicia sesion o registrate!</p>
<div>
    <form action="<?php echo e(route('tienda.ShowLogin')); ?>" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="<?php echo e(route('tienda.ShowRegister')); ?>" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/index.blade.php ENDPATH**/ ?>