<div>
    <form action="<?php echo e(route('tienda.showLogin')); ?>" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="<?php echo e(route('tienda.showRegister')); ?>" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>

<?php if($userRol != 'Guest'): ?>
    <p>Howdy Usuario! Doxeado! :3 ( <?php echo e(session('UserRol')); ?> )</p>
<?php else: ?>
    <p>Inicia sesion o registrate!</p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/index.blade.php ENDPATH**/ ?>