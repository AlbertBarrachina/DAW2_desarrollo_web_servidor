<div>
    Indice de admin
</div>

<div>
    <p>
        Tablero productos
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->unidades); ?></td>
                <td><?php echo e($producto->precio_unitario); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td>
                    <form action="<?php echo e(route('tienda.editProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route ('tienda.destroyProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div>
    <p>
        Tablero categorias
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($categoria->id); ?></td>
                <td><?php echo e($categoria->nombre); ?></td>
                <td><?php echo e($categoria->descripcion); ?></td>
                <td>
                    <form action="<?php echo e(route('tienda.editProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route ('tienda.destroyProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div>
    <p>
        Tablero usuarios
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->unidades); ?></td>
                <td><?php echo e($producto->precio_unitario); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td>
                    <form action="<?php echo e(route('tienda.editProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route ('tienda.destroyProducto', $producto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/adminIndex.blade.php ENDPATH**/ ?>