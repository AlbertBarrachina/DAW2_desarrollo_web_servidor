<?php if(session('UserRol') != 'guest'): ?>
    <button onclick="confirmLogout()">Cerrar sesion</button>
<!--Script para confirmar el logout-->
<script>
    function confirmLogout() {
        var confirmResult = confirm("Quieres cerrar sesión?");

        if (confirmResult) {
            window.location.href = "<?php echo e(route('tienda.Logout')); ?>";
        }
    }
</script>
<?php elseif(session('UserRol') == 'guest'): ?>
<p>Inicia sesion o registrate!</p>
<div>
    <form action="<?php echo e(route('tienda.ShowLogin')); ?>" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="<?php echo e(route('tienda.ShowRegister')); ?>" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
<?php endif; ?>


<?php if(session('UserRol') == 'Admin'): ?>
<div>
    Indice de admin
</div>
<div>
    <p>
        Tablero productos
    </p>
    <!--link al formulario para crear un producto nuevo-->
    <form action="<?php echo e(route ('producto.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear producto</button>
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!--Formulario para actualizar los productos-->
                <form action="<?php echo e(route('producto.update', $producto->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <td><?php echo e($producto->id); ?></td>
                    <td><input type="text" value="<?php echo e($producto->nombre); ?>" name="nombre"></td>
                    <td><input type="text" value="<?php echo e($producto->descripcion); ?>" name="descripcion"></td>
                    <td><input type="text" value="<?php echo e($producto->unidades); ?>" name="unidades"></td>
                    <td><input type="text" value="<?php echo e($producto->precio_unitario); ?>" name="precio_unitario"></td>
                    <td><input type="text" value="<?php echo e($producto->categoria); ?>" name="categoria"></td>
                    <td>
                        <input type="submit" value="Editar producto">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar los productos-->
                    <form action="<?php echo e(route ('producto.destroy', $producto->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no productos-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <!--link al formulario para crear un producto nuevo-->
    <form action="<?php echo e(route ('producto.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear producto</button>
    </form>
</div>

<div>
    <p>
        Tablero categorias
    </p>
    <!--link al formulario para crear una categoria nueva-->
    <form action="<?php echo e(route ('categoria.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear categoria</button>
    </form>
    <!--tabla con las categorias guardadas-->
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!--Formulario para actualizar la categoria-->
                <form action="<?php echo e(route('categoria.update', $categoria->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <td><?php echo e($categoria->id); ?></td>
                    <td><input type="text" value="<?php echo e($categoria->nombre); ?>" name="nombre"></td>
                    <td><input type="text" value="<?php echo e($categoria->descripcion); ?>" name="descripcion"></td>
                    <td>
                        <input type="submit" value="Editar categoria">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar la categoria de esta linea-->
                    <form action="<?php echo e(route ('categoria.destroy', $categoria->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar categoria</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no categorias-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <!--link al formulario para crear una categoria nueva-->
    <form action="<?php echo e(route ('categoria.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear categoria</button>
    </form>
</div>

<div>
    <p>
        Tablero usuarios
    </p>
    <!--link al formulario para crear un usuario nuevo-->
    <form action="<?php echo e(route ('usuario.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear usuario</button>
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!--Formulario para actualizar los usuarios-->
                <form action="<?php echo e(route('usuario.update', $usuario->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <td><?php echo e($usuario->id); ?><input type="hidden" name="id" value="<?php echo e($usuario->id); ?>"></td>
                    <td><input type="text" value="<?php echo e($usuario->nick); ?>" name="nick"></td>
                    <td><input type="text" value="<?php echo e($usuario->email); ?>" name="email"></td>
                    <td><input type="text" value="<?php echo e($usuario->nombre); ?>" name="nombre"></td>
                    <td><input type="text" value="<?php echo e($usuario->apellidos); ?>" name="apellidos"></td>
                    <td><input type="text" value="<?php echo e($usuario->dni); ?>" name="dni"></td>
                    <td><input type="date" value="<?php echo e($usuario->fecha_nacimiento); ?>" name="fecha_nacimiento"></td>
                    <td><input type="text" value="<?php echo e($usuario->contraseña); ?>" name="contraseña"></td>
                    <td>
                        <select name="rol">
                            <option value="<?php echo e($usuario->rol); ?>"><?php echo e($usuario->rol); ?></option>
                            <option value="Usuario">Usuario</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </td>
                    <td>
                        <input type="submit" value="Editar usuario">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar los usuarios-->
                    <form action="<?php echo e(route ('usuario.destroy', $usuario->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($usuario->id); ?>">
                        <button type="submit">Eliminar usuario</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no usuarios-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9">No hay Pproductos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <!--link al formulario para crear un usuario nuevo-->
    <form action="<?php echo e(route ('usuario.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <button type="submit">Crear usuario</button>
    </form>
</div>
<?php else: ?>
<p>
    Ups! No tendrias que estar aqui!
</p>
<div>
    <form action="<?php echo e(route('producto.index')); ?>" method="GET">
        <input type="submit" value="Volver a los productos">
    </form>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/adminIndex.blade.php ENDPATH**/ ?>