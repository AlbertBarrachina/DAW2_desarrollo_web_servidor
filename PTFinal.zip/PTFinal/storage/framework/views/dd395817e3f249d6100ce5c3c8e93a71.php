<div>
    <p>
        Tablero categorias
    </p>
    <form action="<?php echo e(route ('categoria.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="descripcion" placeholder="Descripción">
        <button type="submit">Crear categoria</button>
    </form>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/categorias.blade.php ENDPATH**/ ?>