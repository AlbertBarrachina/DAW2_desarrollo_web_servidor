<div>
    <p>
        Tablero categorias
    </p>
    <form action="<?php echo e(route('tienda.Perfil')); ?>" method="GET">
        <input type="submit" value="Perfil">
    </form>
    <form action="<?php echo e(route('producto.index')); ?>" method="GET">
        <input type="submit" value="Catalogo">
    </form>
    <form action="<?php echo e(route('carrito.index')); ?>" method="GET">
        <input type="submit" value="Carrito">
    </form>
    <!--tabla con las categorias guardadas-->
    <table border=1>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripcion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!--Categorias existentes-->
                <td><?php echo e($categoria->nombre); ?></td>
                <td><?php echo e($categoria->descripcion); ?></td>
            </tr>
            <!--mensaje de no categorias-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">No hay categorias registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\PTFinal\resources\views/tienda/categorias.blade.php ENDPATH**/ ?>