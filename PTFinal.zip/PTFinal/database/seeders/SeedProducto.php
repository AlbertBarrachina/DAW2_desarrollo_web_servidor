<?php

namespace Database\Seeders;

use App\Models\ProductoModel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SeedProducto extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $productoData = [
            [
                'nombre' => 'silla',
                'descripcion' => 'silla de camping',
                'unidades' => '37',
                'precio_unitario' => '15',
                'categoria' => 'mueble',
            ],
            [
                'nombre' => 'puerta',
                'descripcion' => 'puerta de madera',
                'unidades' => '23',
                'precio_unitario' => '40',
                'categoria' => 'construccion',
            ],
            [
                'nombre' => 'mesa',
                'descripcion' => 'mesa, presuntamente madera.',
                'unidades' => '74',
                'precio_unitario' => '50',
                'categoria' => 'mueble',
            ],
            [
                'nombre' => 'cajonera',
                'descripcion' => 'cajonera para guardar piedras preciosas',
                'unidades' => '6',
                'precio_unitario' => '430',
                'categoria' => 'mueble',
            ],
            [
                'nombre' => 'teja',
                'descripcion' => 'teja premium',
                'unidades' => '2364',
                'precio_unitario' => '2',
                'categoria' => 'construccion',
            ],
            [
                'nombre' => 'kit vajilleria',
                'descripcion' => 'kit con todo tipo de vajilleria',
                'unidades' => '8',
                'precio_unitario' => '156',
                'categoria' => 'Fragil',
            ],
        ];

        // Insert the data into the database
        foreach ($productoData as $data) {
            ProductoModel::create($data);
        }
    }
}
