<?php

namespace Database\Seeders;

use App\Models\CategoriaModel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SeedCategoria extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categoriaData = [
            [
                'nombre' => 'construccion',
                'descripcion' => 'Elementos de construccion como una pared el suelo o una puerta.',
            ],
            [
                'nombre' => 'mueble',
                'descripcion' => 'Un mueble.',
            ],
            [
                'nombre' => 'Fragil',
                'descripcion' => 'Productos fragiles que pueden ser destruidos durante el viaje.',
            ],
        ];

        // Insert the data into the database
        foreach ($categoriaData as $data) {
            CategoriaModel::create($data);
        }
    }
}
