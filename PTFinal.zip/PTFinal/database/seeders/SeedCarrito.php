<?php

namespace Database\Seeders;

use App\Models\CarritoModel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SeedCarrito extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $carritoData = [
            [
                'producto' => 'silla',
                'cantidad' => '2',
                'precio_producto' => '15',
                'total' => '30',
            ],
            [
                'producto' => 'puerta',
                'cantidad' => '5',
                'precio_producto' => '40',
                'total' => '200',
            ],
            [
                'producto' => 'kit vajilleria',
                'cantidad' => '10',
                'precio_producto' => '156',
                'total' => '1560',
            ],
            [
                'producto' => 'mesa',
                'cantidad' => '1',
                'precio_producto' => '50',
                'total' => '50',
            ],
        ];

        // Insert the data into the database
        foreach ($carritoData as $data) {
            CarritoModel::create($data);
        }
    }
}
