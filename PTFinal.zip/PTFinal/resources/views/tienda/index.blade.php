@if(session('UserRol') != 'guest')
<button onclick="confirmLogout()">Cerrar sesion</button>
<!--Script para confirmar el logout-->
<script>
    function confirmLogout() {
        var confirmResult = confirm("Quieres cerrar sesión?");

        if (confirmResult) {
            window.location.href = "{{route('tienda.Logout')}}";
        }
    }
</script>
@elseif(session('UserRol') == 'guest')
<p>Inicia sesion o registrate!</p>
<div>
    <form action="{{route('tienda.ShowLogin')}}" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="{{route('tienda.ShowRegister')}}" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
@endif