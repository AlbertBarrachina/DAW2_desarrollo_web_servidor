<div>
    <form action="{{route('tienda.showLogin')}}" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="{{route('tienda.showRegister')}}" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>

@if($userRol != 'Guest')
    <p>Howdy Usuario! Doxeado! :3 ( {{session('UserRol')}} )</p>
@else
    <p>Inicia sesion o registrate!</p>
@endif