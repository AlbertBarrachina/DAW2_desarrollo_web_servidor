@if(session('UserRol') != 'guest')
<form action="{{route('tienda.Logout')}}" method="GET">
    <input type="submit" value="Cerrar sesion">
</form>
@elseif(session('UserRol') == 'guest')
<p>Inicia sesion o registrate!</p>
<div>
    <form action="{{route('tienda.ShowLogin')}}" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="{{route('tienda.ShowRegister')}}" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
@endif