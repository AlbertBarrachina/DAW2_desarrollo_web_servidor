<div>
    <p>
        Crear categoria
    </p>
    <form action="{{route ('categoria.store')}}" method="POST">
        @csrf
        @method('POST')
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="descripcion" placeholder="Descripción">
        <button type="submit">Crear categoria</button>
    </form>
</div>