<div>
    <p>
        Crear usuario
    </p>
    <form action="{{route ('usuario.store')}}" method="POST">
        @csrf
        @method('POST')
        <input type="text" name="nick" placeholder="Nick">
        <input type="text" name="email" placeholder="Email">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="apellidos" placeholder="Apellidos">
        <input type="text" name="dni" placeholder="DNI">
        <input type="date" name="fecha_nacimiento" placeholder="fecha de nacimiento">
        <input type="text" name="contraseña" placeholder="Contraseña">
        <input type="text" name="repetir_contraseña" placeholder="Repita la contraseña">
        <button type="submit">Crear usuario</button>
    </form>
</div>