<div>
    <p>
        Tablero productos
    </p>
    <form action="{{route('tienda.Perfil')}}" method="GET">
        <input type="submit" value="Perfil">
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($productos as $producto)
            <tr>
                <!--Formulario para actualizar los productos-->
                <form action="{{route('carrito.store', $producto->id)}}" method="POST">
                    @csrf
                    @method('POT')
                    <td>{{$producto->id}}</td>
                    <td>{{$producto->nombre}}</td>
                    <td>{{$producto->descripcion}}</td>
                    <td>{{$producto->unidades}}</td>
                    <td>{{$producto->precio_unitario}}</td>
                    <td>{{$producto->categoria}}</td>
                    <td><input type="number" name="cantidad" value="0"></td>
                    <td>
                        <input type="submit" value="Añadir al carrito">
                    </td>
                </form>
            </tr>
            <!--mensaje de no productos-->
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>