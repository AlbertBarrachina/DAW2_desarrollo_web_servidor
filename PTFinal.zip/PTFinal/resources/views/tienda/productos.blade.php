<div>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($productos as $producto)
            <tr>
                <td>{{$producto->id}}</td>
                <td>{{$producto->nombre}}</td>
                <td>{{$producto->descripcion}}</td>
                <td>{{$producto->unidades}}</td>
                <td>{{$producto->precio_unitario}}</td>
                <td>{{$producto->categoria}}</td>
                <td>
                    <form action="{{route('tienda.editProducto', $producto->id)}}">
                        @csrf
                        @method('post')
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="{{route ('tienda.destroyProducto', $producto->id)}}">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
{{$userRol}}
@if($userRol == 'Admin')
    <form action="{{route('tienda.showAdmin')}}">
        <button action="submit">Zona admin</button>
    </form>
@elseif($userRol == 'Usuario')
    <p>Howdy Usuario! Doxeado! :3 {{session('UserRol')}}</p>
@else
    <p>Inicia sesion o registrate!</p>
@endif