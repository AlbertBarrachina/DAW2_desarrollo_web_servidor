<div>
    Indice de admin
</div>

<div>
    <p>
        Tablero productos
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($productos as $producto)
            <tr>
                <td>{{$producto->id}}</td>
                <td>{{$producto->nombre}}</td>
                <td>{{$producto->descripcion}}</td>
                <td>{{$producto->unidades}}</td>
                <td>{{$producto->precio_unitario}}</td>
                <td>{{$producto->categoria}}</td>
                <td>
                    <form action="{{route('tienda.editProducto', $producto->id)}}">
                        @csrf
                        @method('post')
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="{{route ('tienda.destroyProducto', $producto->id)}}">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div>
    <p>
        Tablero categorias
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>>
            </tr>
        </thead>
        <tbody>
            @forelse ($categorias as $categoria)
            <tr>
                <td>{{$categoria->id}}</td>
                <td>{{$categoria->nombre}}</td>
                <td>{{$categoria->descripcion}}</td>
                <td>
                    <form action="{{route('tienda.editProducto', $producto->id)}}">
                        @csrf
                        @method('post')
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="{{route ('tienda.destroyProducto', $producto->id)}}">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div>
    <p>
        Tablero usuarios
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($productos as $producto)
            <tr>
                <td>{{$producto->id}}</td>
                <td>{{$producto->nombre}}</td>
                <td>{{$producto->descripcion}}</td>
                <td>{{$producto->unidades}}</td>
                <td>{{$producto->precio_unitario}}</td>
                <td>{{$producto->categoria}}</td>
                <td>
                    <form action="{{route('tienda.editProducto', $producto->id)}}">
                        @csrf
                        @method('post')
                        <input type="submit" value="Actualizar producto">
                    </form>
                </td>
                <td>
                    <form action="{{route ('tienda.destroyProducto', $producto->id)}}">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>