@if(session('UserRol') != 'guest')
    <button onclick="confirmLogout()">Cerrar sesion</button>
<!--Script para confirmar el logout-->
<script>
    function confirmLogout() {
        var confirmResult = confirm("Quieres cerrar sesión?");

        if (confirmResult) {
            window.location.href = "{{route('tienda.Logout')}}";
        }
    }
</script>
@elseif(session('UserRol') == 'guest')
<p>Inicia sesion o registrate!</p>
<div>
    <form action="{{route('tienda.ShowLogin')}}" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="{{route('tienda.ShowRegister')}}" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
@endif


@if(session('UserRol') == 'Admin')
<div>
    Indice de admin
</div>
<div>
    <p>
        Tablero productos
    </p>
    <!--link al formulario para crear un producto nuevo-->
    <form action="{{route ('producto.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear producto</button>
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Unidades</th>
                <th>Precio unidad</th>
                <th>Categoria</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($productos as $producto)
            <tr>
                <!--Formulario para actualizar los productos-->
                <form action="{{route('producto.update', $producto->id)}}" method="POST">
                    @csrf
                    @method('put')
                    <td>{{$producto->id}}</td>
                    <td><input type="text" value="{{$producto->nombre}}" name="nombre"></td>
                    <td><input type="text" value="{{$producto->descripcion}}" name="descripcion"></td>
                    <td><input type="text" value="{{$producto->unidades}}" name="unidades"></td>
                    <td><input type="text" value="{{$producto->precio_unitario}}" name="precio_unitario"></td>
                    <td><input type="text" value="{{$producto->categoria}}" name="categoria"></td>
                    <td>
                        <input type="submit" value="Editar producto">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar los productos-->
                    <form action="{{route ('producto.destroy', $producto->id)}}" method="POST">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar producto</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no productos-->
            @empty
            <tr>
                <td colspan="6">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    <!--link al formulario para crear un producto nuevo-->
    <form action="{{route ('producto.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear producto</button>
    </form>
</div>

<div>
    <p>
        Tablero categorias
    </p>
    <!--link al formulario para crear una categoria nueva-->
    <form action="{{route ('categoria.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear categoria</button>
    </form>
    <!--tabla con las categorias guardadas-->
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($categorias as $categoria)
            <tr>
                <!--Formulario para actualizar la categoria-->
                <form action="{{route('categoria.update', $categoria->id)}}" method="POST">
                    @csrf
                    @method('PATCH')
                    <td>{{$categoria->id}}</td>
                    <td><input type="text" value="{{$categoria->nombre}}" name="nombre"></td>
                    <td><input type="text" value="{{$categoria->descripcion}}" name="descripcion"></td>
                    <td>
                        <input type="submit" value="Editar categoria">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar la categoria de esta linea-->
                    <form action="{{route ('categoria.destroy', $categoria->id)}}" method="POST">
                        @csrf
                        @method('delete')
                        <button type="submit">Eliminar categoria</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no categorias-->
            @empty
            <tr>
                <td colspan="3">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    <!--link al formulario para crear una categoria nueva-->
    <form action="{{route ('categoria.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear categoria</button>
    </form>
</div>

<div>
    <p>
        Tablero usuarios
    </p>
    <!--link al formulario para crear un usuario nuevo-->
    <form action="{{route ('usuario.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear usuario</button>
    </form>
    <table border=1>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($usuarios as $usuario)
            <tr>
                <!--Formulario para actualizar los usuarios-->
                <form action="{{route('usuario.update', $usuario->id)}}" method="POST">
                    @csrf
                    @method('PATCH')
                    <td>{{$usuario->id}}<input type="hidden" name="id" value="{{ $usuario->id }}"></td>
                    <td><input type="text" value="{{$usuario->nick}}" name="nick"></td>
                    <td><input type="text" value="{{$usuario->email}}" name="email"></td>
                    <td><input type="text" value="{{$usuario->nombre}}" name="nombre"></td>
                    <td><input type="text" value="{{$usuario->apellidos}}" name="apellidos"></td>
                    <td><input type="text" value="{{$usuario->dni}}" name="dni"></td>
                    <td><input type="date" value="{{$usuario->fecha_nacimiento}}" name="fecha_nacimiento"></td>
                    <td><input type="text" value="{{$usuario->contraseña}}" name="contraseña"></td>
                    <td>
                        <select name="rol">
                            <option value="{{$usuario->rol}}">{{$usuario->rol}}</option>
                            <option value="Usuario">Usuario</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </td>
                    <td>
                        <input type="submit" value="Editar usuario">
                    </td>
                </form>
                <td>
                    <!--Formulario para eliminar los usuarios-->
                    <form action="{{route ('usuario.destroy', $usuario->id)}}" method="POST">
                        @csrf
                        @method('delete')
                        <input type="hidden" name="id" value="{{ $usuario->id }}">
                        <button type="submit">Eliminar usuario</button>
                    </form>
                </td>
            </tr>
            <!--mensaje de no usuarios-->
            @empty
            <tr>
                <td colspan="9">No hay Pproductos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    <!--link al formulario para crear un usuario nuevo-->
    <form action="{{route ('usuario.create')}}" method="POST">
        @csrf
        @method('GET')
        <button type="submit">Crear usuario</button>
    </form>
</div>
@else
<p>
    Ups! No tendrias que estar aqui!
</p>
<div>
    <form action="{{route('producto.index')}}" method="GET">
        <input type="submit" value="Volver a los productos">
    </form>
</div>
@endif