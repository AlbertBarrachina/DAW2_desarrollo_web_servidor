@if(session('UserRol') != 'guest')
<form action="{{route('tienda.Logout')}}" method="GET">
    <input type="submit" value="Cerrar sesion">
</form>
@elseif(session('UserRol') == 'guest')
<p>Inicia sesion o registrate!</p>
<div>
    <form action="{{route('tienda.ShowLogin')}}" method="GET">
        <input type="submit" value="Iniciar sesion">
    </form>
    <form action="{{route('tienda.ShowRegister')}}" method="GET">
        <input type="submit" value="Registrate">
    </form>
</div>
@endif
<div>
    <p>
        Perfil de {{$usuario->nick}}
    </p>
    <table border=1>
        <thead>
            <tr>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha nacimiento</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th colspan="2">acción</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <!--Formulario para actualizar los usuarios-->
                <form action="{{route('tienda.UpdatePerfil')}}" method="POST">
                    @csrf
                    @method('PATCH')
                    <input hidden type="number" name="id" value="{{$usuario->id}}">
                    <td><input type="text" value="{{$usuario->nick}}" name="nick"></td>
                    <td><input type="text" value="{{$usuario->email}}" name="email"></td>
                    <td>{{$usuario->nombre}}</td>
                    <td>{{$usuario->apellidos}}</td>
                    <td>{{$usuario->dni}}</td>
                    <td>{{$usuario->fecha_nacimiento}}</td>
                    <td>{{$usuario->contraseña}}</td>
                    <td>{{$usuario->rol}}</td>
                    <td>
                        <input type="submit" value="Actualizar usuario">
                    </td>
                </form>
            </tr>
        </tbody>
    </table>
</div>