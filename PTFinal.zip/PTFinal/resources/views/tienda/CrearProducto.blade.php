<div>
    <p>
        Tablero categorias
    </p>
    <form action="{{route ('producto.store')}}" method="POST">
        @csrf
        @method('POST')
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="descripcion" placeholder="Descripción">
        <input type="number" name="unidades" value="1">
        <input type="number" name="precio_unitario" value="1">
        <select name="categoria">
            <option value="">--</option>
            @forelse ($categorias as $categoria)
            <option value="{{$categoria->nombre}}">{{$categoria->nombre}}</option>
            @empty
            <option value="">--</option>
            @endforelse
        </select>
        <button type="submit">Crear producto</button>
    </form>
</div>