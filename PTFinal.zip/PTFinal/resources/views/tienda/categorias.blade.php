<div>
    <p>
        Tablero categorias
    </p>
    <form action="{{route('tienda.Perfil')}}" method="GET">
        <input type="submit" value="Perfil">
    </form>
    <form action="{{route('producto.index')}}" method="GET">
        <input type="submit" value="Catalogo">
    </form>
    <form action="{{route('carrito.index')}}" method="GET">
        <input type="submit" value="Carrito">
    </form>
    <!--tabla con las categorias guardadas-->
    <table border=1>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripcion</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($categorias as $categoria)
            <tr>
                <!--Categorias existentes-->
                <td>{{$categoria->nombre}}</td>
                <td>{{$categoria->descripcion}}</td>
            </tr>
            <!--mensaje de no categorias-->
            @empty
            <tr>
                <td colspan="3">No hay categorias registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>