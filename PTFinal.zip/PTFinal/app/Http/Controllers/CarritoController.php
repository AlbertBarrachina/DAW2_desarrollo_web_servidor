<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CarritoModel;

class CarritoController extends Controller
{
     //index
     public function index()
     {
         return $this->show();
     }
 
     //show
     public function show()
     {
        $productos = CarritoModel::all();
         return view('tienda.carrito',compact('productos'));
     }
     //create
     public function create()
     {
        $categorias = CarritoModel::all();
         return view('tienda.CrearProducto',compact('categorias'));
     }

    //store
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required',
            'descripcion' => 'required',
            'unidades' => 'required|numeric',
            'precio_unitario' => 'required',
            'categoria' => 'required| exists:categorias,nombre'
        ]);
        CarritoModel::create($request->all());

        // Redirigir a la lista de tareas con un mensaje
        return $this->index();
    }

    //update
    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required',
            'descripcion' => 'required',
            'unidades' => 'required|numeric',
            'precio_unitario' => 'required',
            'categoria' => 'required| exists:categorias,nombre'
        ]);
        $producto = CarritoModel::findOrFail($id);

        // actuliza el usuario
        $producto->update($request->all());

        return $this->index();
    }

    //detroy
    public function destroy(Request $request, $id)
    {
        $producto = CarritoModel::findOrFail($id);
        $producto->delete();
        return $this->index();
    }
}
