<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsuarioModel;

class UsuarioController extends Controller
{

    //index
    public function index()
    {
        return redirect()->route('tienda.ShowAdmin');
    }

    //show
    public function show()
    {
        return $this->index();
    }

    //create
    public function create()
    {
        return view('tienda.usuarios');
    }

    public function store(Request $request)
    {
        $request->merge(['rol' => $request->input('rol', 'Usuario')]);
        $request->validate([
            'nick' => 'required',
            'email' => 'required',
            'nombre' => 'required',
            'apellidos' => 'required',
            'dni' => 'required',
            'fecha_nacimiento' => 'required|date',
            'contraseña' => 'required|same:repetir_contraseña',
            'rol' => 'required|in:Usuario,Admin',
        ]);
        UsuarioModel::create($request->all());

        return $this->index();
    }

    public function update(Request $request)
    {
        $request->validate([
            'nick' => 'required',
            'email' => 'required',
            'nombre' => 'required',
            'apellidos' => 'required',
            'dni' => 'required',
            'fecha_nacimiento' => 'required|date',
            'contraseña' => 'required',
            'rol' => 'required|in:Usuario,Admin',
        ]);
        $usuario = UsuarioModel::findOrFail($request->id);

        // actuliza el usuario
        $usuario->update($request->all());

        return $this->index();
    }

    public function destroy(Request $request)
    {
        $usuario = UsuarioModel::findOrFail($request->id);
        $usuario->delete();
        return $this->index();
    }
}
