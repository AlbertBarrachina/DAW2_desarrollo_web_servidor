<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\CategoriaModel;

class CategoriaController extends Controller
{

    //index
    public function index()
    {
        return $this->show();
    }
    //show
    public function show()
    {
        $categorias = CategoriaModel::all();
         return view('tienda.categorias',compact('categorias'));
    }

    //create
    public function create()
    {
        return view('tienda.CrearCategoria');
    }
    //store
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required',
            'descripcion' => 'required'
        ]);
        CategoriaModel::create($request->all());

        return $this->index();
    }

    //update
    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required',
            'descripcion' => 'required'
        ]);
        $categoria = CategoriaModel::findOrFail($id);
        // actuliza el usuario
        $categoria->update($request->all());
        return $this->index();
    }

    //destroy
    public function destroy(Request $request, $id)
    {
        $categoria = CategoriaModel::findOrFail($id);
        $categoria->delete();
        return $this->index();
    }
}
