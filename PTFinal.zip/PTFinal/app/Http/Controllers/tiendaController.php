<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsuarioModel;
use App\Models\CategoriaModel;
use App\Models\ProductoModel;
use App\Models\CarritoModel;

class tiendaController extends Controller
{
    //

    public function index() {
        return view('tienda.index');
    }

    public function showLogin() {
        return view('tienda.login');
    }
    
    public function showRegister() {
        return view('tienda.register');
    }

    public function showProductos() {
        $productos = ProductoModel::all();
        return view('tienda.productos', compact('productos'));
    }

    public function showAdmin() {
        $productos = ProductoModel::all();
        $categorias = CategoriaModel::all();
        $usuarios = UsuarioModel::all();
        return view('tienda.adminIndex', compact('productos', 'categorias', 'usuarios'));
    }

    public function Login(Request $request) {
        $nick = $request->input('nick');
        $password = $request->input('password');

        $user = UsuarioModel::where('nick', $nick)->where('contraseña', $password)->first();

        if ($user) {
            error_log($user->rol);
            session(['UserRol' => $user->rol]);

           return $this->showProductos();
        } else {
            return redirect('/showLogin')->with('error', 'Error al intentar iniciar sesion');
        }
    }

    

    /* CRUD usuario */

    public function storeUsuario(Request $request){
        $request->merge(['rol' => $request->input('rol', 'Usuario')]);
        $request->validate([
            'nick' => 'required',
            'email' => 'required',
            'nombre' => 'required',
            'apellidos' => 'required',
            'dni' => 'required',
            'fecha_nacimiento' => 'required|date',
            'contraseña' => 'required|same:repetir_contraseña',
            'rol' => 'required|in:Usuario,Admin',
        ]);
        UsuarioModel::create($request->all());

        // Redirigir a la lista de tareas con un mensaje
        return redirect()->route('tienda.index');
    }

    public function DeleteUsuario(Request $request){
        
        // Redirigir a la lista de tareas con un mensaje
        return redirect()->route('tienda.index');
    }
    /* CRUD categoria */


    /* CRUD productos */


}
