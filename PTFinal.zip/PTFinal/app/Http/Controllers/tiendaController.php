<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsuarioModel;
use App\Models\CategoriaModel;
use App\Models\ProductoModel;
use App\Models\CarritoModel;

class tiendaController extends Controller
{
    //

    public function index()
    {
        return view('tienda.index');
    }

    public function ShowLogin()
    {
        return view('tienda.login');
    }

    public function ShowRegister()
    {
        return view('tienda.register');
    }
    public function Perfil()
    { $usuario = UsuarioModel::findOrFail(session('UserID'));
        return view('tienda.perfil', compact('usuario'));
    }

    public function UpdatePerfil(Request $request)
    { 
        $request->validate([
            'nick' => 'required',
            'email' => 'required'
        ]);
        $usuario = UsuarioModel::findOrFail($request->id);

        // actuliza el usuario
        $usuario->update($request->all());
        return view('tienda.perfil', compact('usuario'));
    }

    public function ShowAdmin()
    {
        $productos = ProductoModel::all();
        $categorias = CategoriaModel::all();
        $usuarios = UsuarioModel::all();

        return view('tienda.adminIndex', compact('productos', 'categorias', 'usuarios'));
       
    }

    public function Login(Request $request)
    {
        $nick = $request->input('nick');
        $password = $request->input('password');

        $user = UsuarioModel::where('nick', $nick)->where('contraseña', $password)->first();

        if ($user) {
            error_log($user->rol);
            session(['UserRol' => $user->rol]);
            session(['UserID' => $user->id]);

            if($user->rol !='Admin'){
                return app(ProductoController::class)->show();
            }else{
                return $this->ShowAdmin();
            }
            
        } else {
            return redirect('/ShowLogin')->with('error', 'Error al intentar iniciar sesion');
        }
    }
    public function Logout(Request $request)
    {
            session(['UserRol' => 'guest']);
            session(['UserID' => '0']);
            return $this->index();
    }

}
